package com.example.gmap;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.maps.android.data.Feature;
import com.google.maps.android.data.kml.KmlContainer;
import com.google.maps.android.data.kml.KmlLayer;
import com.google.maps.android.data.kml.KmlPlacemark;
import com.google.maps.android.data.kml.KmlPoint;

import net.qxcg.svy21.*;

import com.opencsv.CSVReader;
import java.io.IOException;
import java.io.FileReader;

import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    private FloatingActionButton button_location;
    private Chip chip_pcn;
    private Chip chip_carpark;
    private Chip chip_hawker;

    private KmlLayer layer_pcn;
    private KmlLayer layer_carpark;
    private KmlLayer layer_hawker;

    private ArrayList<Marker> arrayList_hawker = new ArrayList<Marker>();
    private ArrayList<Marker> arrayList_carpark = new ArrayList<Marker>();

    private static final int ACCESS_FINE_LOCATION_CODE = 1;
    private boolean permission_acquired = false;

    private FusedLocationProviderClient fusedLocationClient;

    private Location current_location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        button_location = findViewById(R.id.button_location);
        button_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (permission_acquired == false) {
                    checkPermission(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            ACCESS_FINE_LOCATION_CODE);
                }
                if (permission_acquired == true){
                    moveCameraToUser();
                }

            }
        });

        chip_pcn = findViewById(R.id.chip_pcn);
        chip_pcn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    try {
                        showPCN();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (XmlPullParserException e) {
                        e.printStackTrace();
                    }
                }
                else{
                    hidePCN();
                }
            }
        });


        chip_carpark = findViewById(R.id.chip_carpark);
        chip_carpark.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    try {
                        showCarpark();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (XmlPullParserException e) {
                        e.printStackTrace();
                    }
                }
                else{
                    hideCarpark();
                }
            }
        });


        chip_hawker = findViewById(R.id.chip_hawker);
        chip_hawker.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    try {
                        showHawker();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (XmlPullParserException e) {
                        e.printStackTrace();
                    }
                }
                else{
                    hideHawker();
                }
            }
        });
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng singapore = new LatLng(1.2903, 103.85);
        //mMap.addMarker(new MarkerOptions().position(singapore).title("Singapore"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(singapore));
        mMap.moveCamera(CameraUpdateFactory.zoomTo(10));
    }

    public void checkPermission(String permission, int requestCode)
    {
        //Acquire permission
        if (ContextCompat.checkSelfPermission(this, permission)
                == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this,
                    new String[] { permission },
                    requestCode);
        }
        else {
            permission_acquired = true;
            /*
            Toast.makeText(this,
                    "Permission already granted",
                    Toast.LENGTH_SHORT)
                    .show();
            */
        }
    }

    @SuppressLint("MissingPermission")

    public void moveCameraToUser(){
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            current_location = location;
                            LatLng current_LatLng =  new LatLng(current_location.getLatitude(), current_location.getLongitude());
                            mMap.addMarker(new MarkerOptions().position(current_LatLng).title("You Are Here!").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN)));
                            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(current_LatLng, 12));
                        }
                    }
                });
    }

    public void showPCN() throws IOException, XmlPullParserException {

        layer_pcn = new KmlLayer(mMap, R.raw.park_connector_loop_kml, this);
        layer_pcn.addLayerToMap();
    }

    public void hidePCN(){
        layer_pcn.removeLayerFromMap();
    }



    public void showCarpark() throws IOException, XmlPullParserException {
        //Log.i("qwe", "success");

        //CSVReader reader = new CSVReader(new FileReader("C:\\Users\\11219\\AndroidStudioProjects\\Gmap\\app\\src\\main\\res\\raw\\hdb_carpark.csv"));
        //Log.i("qwe", "success");
        InputStream is = getResources().openRawResource(R.raw.hdb_carpark);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
        String nextLine = "";
        nextLine = reader.readLine();
        try {
            while ((nextLine = reader.readLine()) != null) {
                //Log.i("qwe", nextLine[0]);
                String[] tokens = nextLine.split(",");
                Double svy_x = Double.parseDouble(tokens[2].substring(1,tokens[2].length()-1));
                Double svy_y = Double.parseDouble(tokens[3].substring(1,tokens[3].length()-1));
                SVY21Coordinate svy = new SVY21Coordinate(svy_y, svy_x);
                LatLonCoordinate latlon = SVY21.computeLatLon(svy);
                LatLng latLng= new LatLng(latlon.getLatitude(), latlon.getLongitude());
                String name = tokens[0].substring(1,tokens[0].length()-1) + ", " + tokens[1].substring(1,tokens[1].length()-1);
                Marker marker = mMap.addMarker(new MarkerOptions().position(latLng).title(name).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
                arrayList_carpark.add(marker);
            }
        } catch (IOException e) {


        }
    }


    public void hideCarpark(){
        for(Marker marker : arrayList_carpark){
            marker.remove();
        }
        arrayList_carpark = new ArrayList<Marker>();
    }



    public void showHawker() throws IOException, XmlPullParserException {
        layer_hawker = new KmlLayer(mMap, R.raw.hawker_centres_kml, this);
        layer_hawker.addLayerToMap();
        createMarkers(layer_hawker.getContainers());
        layer_hawker.removeLayerFromMap();
    }

    public void hideHawker(){
        for(Marker marker : arrayList_hawker){
            marker.remove();
        }
        arrayList_hawker = new ArrayList<Marker>();
    }

    public void createMarkers(Iterable<KmlContainer> containers) {
        for (KmlContainer container : containers) {
            if (container.hasContainers()) {
                createMarkers(container.getContainers());
            }
            else for (KmlPlacemark placemark : container.getPlacemarks()){
                if(placemark.getGeometry().getGeometryType().equals("Point")) {
                    KmlPoint point = (KmlPoint) placemark.getGeometry();
                    LatLng latLng = new LatLng(point.getGeometryObject().latitude, point.getGeometryObject().longitude);
                    String description = placemark.getProperty("description");
                    int start = description.indexOf("<th>NAME</th>\n") + "<th>NAME</th>\n".length() ;
                    int end = description.indexOf("</td>", start);
                    start += "<td>".length();
                    String hawkerName = description.substring(start, end);
                    Marker marker = mMap.addMarker(new MarkerOptions().position(latLng).title(hawkerName).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
                    arrayList_hawker.add(marker);

                }
            }
        }
    }

}